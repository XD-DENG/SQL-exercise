create definer = root@`%` view view_replenishment_goods_list as
select `a`.`id`             AS `id`,
       `a`.`device_id`      AS `device_id`,
       `drd`.`container_id` AS `container_id`,
       `drd`.`row`          AS `row`,
       `drd`.`col`          AS `col`,
       `drd`.`goods_id`     AS `goods_id`,
       `drd`.`goods_name`   AS `goods_name`,
       `drd`.`num`          AS `num`,
       `a`.`mch_id`         AS `mch_id`,
       `a`.`create_time`    AS `create_time`,
       `a`.`staff_id`       AS `staff_id`,
       `a`.`opt_id`         AS `opt_id`,
       `b`.`goods_name`     AS `tradeName`,
       `b`.`num`            AS `replenishment_num`,
       `c`.`code`           AS `goods_code`
from (((`sweeppayvendingcommon`.`dc_replenishment_record` `a` join `sweeppayvendingcommon`.`dc_replenishment_record_detail` `drd` on ((`a`.`id` = `drd`.`record_id`))) left join `sweeppayvendingcommon`.`dc_replenishment_goods_list` `b` on ((`a`.`device_id` = `b`.`device_id`)))
         left join `sweeppayvendingcommon`.`dc_goods` `c` on ((`b`.`goods_id` = `c`.`id`)));

-- comment on column view_replenishment_goods_list.id not supported: 补货记录唯一标识

-- comment on column view_replenishment_goods_list.device_id not supported: 售货机ID

-- comment on column view_replenishment_goods_list.container_id not supported: 货柜机型ID

-- comment on column view_replenishment_goods_list.row not supported: 货道行号

-- comment on column view_replenishment_goods_list.col not supported: 货道列号

-- comment on column view_replenishment_goods_list.goods_id not supported: 商品ID

-- comment on column view_replenishment_goods_list.goods_name not supported: 商品名称

-- comment on column view_replenishment_goods_list.num not supported: 补货数量

-- comment on column view_replenishment_goods_list.mch_id not supported: 商户ID

-- comment on column view_replenishment_goods_list.create_time not supported: 创建时间

-- comment on column view_replenishment_goods_list.staff_id not supported: 补货员ID

-- comment on column view_replenishment_goods_list.opt_id not supported: 执行人

-- comment on column view_replenishment_goods_list.tradeName not supported: 商品名称

-- comment on column view_replenishment_goods_list.replenishment_num not supported: 补货数量

-- comment on column view_replenishment_goods_list.goods_code not supported: 编号


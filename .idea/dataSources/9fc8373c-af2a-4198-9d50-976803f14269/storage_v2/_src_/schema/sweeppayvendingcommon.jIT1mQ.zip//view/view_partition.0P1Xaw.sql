create definer = root@`%` view view_partition as
select `p`.`id`               AS `id`,
       `p`.`name`             AS `name`,
       `p`.`status`           AS `status`,
       `p`.`charge_man`       AS `charge_man`,
       `p`.`phone`            AS `phone`,
       `p`.`mch_id`           AS `mch_id`,
       `p`.`org_id`           AS `org_id`,
       `p`.`create_time`      AS `create_time`,
       `p`.`creator_id`       AS `creator_id`,
       `p`.`last_modify_time` AS `last_modify_time`,
       `p`.`last_modifier_id` AS `last_modifier_id`,
       `m`.`admin_id`         AS `admin_id`,
       `m`.`name`             AS `merchant_name`,
       `o`.`code`             AS `org_code`,
       `o`.`name`             AS `org_name`,
       `o`.`relation_tree`    AS `relation_tree`
from ((`sweeppayvendingcommon`.`dc_partition` `p` left join `sweeppayvendingcommon`.`dc_merchant` `m` on ((`p`.`mch_id` = `m`.`id`)))
         left join `sweeppayvendingcommon`.`dc_org` `o` on ((`p`.`org_id` = `o`.`id`)));

-- comment on column view_partition.id not supported: 点位分区唯一标识

-- comment on column view_partition.name not supported: 点位分区名称

-- comment on column view_partition.status not supported: 状态 0 禁用 1 启用

-- comment on column view_partition.charge_man not supported: 负责人

-- comment on column view_partition.phone not supported: 联系电话

-- comment on column view_partition.mch_id not supported: 商户ID

-- comment on column view_partition.org_id not supported: 所属机构ID

-- comment on column view_partition.create_time not supported: 创建时间

-- comment on column view_partition.creator_id not supported: 创建人ID

-- comment on column view_partition.last_modify_time not supported: 最后修改时间

-- comment on column view_partition.last_modifier_id not supported: 最后修改者ID

-- comment on column view_partition.admin_id not supported: 管理员ID

-- comment on column view_partition.merchant_name not supported: 名称

-- comment on column view_partition.org_code not supported: 编码

-- comment on column view_partition.org_name not supported: 名称

-- comment on column view_partition.relation_tree not supported: 关系树，用“-”分割机构ID，如：1-2-3-


create definer = root@`%` view view_ad_device as
select `ad`.`id`                   AS `id`,
       `ad`.`no`                   AS `no`,
       `ad`.`name`                 AS `name`,
       `ad`.`file_type`            AS `file_type`,
       `ad`.`path`                 AS `path`,
       `ad`.`size`                 AS `size`,
       `ad`.`effective_start_time` AS `effective_start_time`,
       `ad`.`effective_end_time`   AS `effective_end_time`,
       `ad`.`status`               AS `status`,
       `ad`.`memo`                 AS `memo`,
       `ad`.`mch_id`               AS `mch_id`,
       `ad`.`create_time`          AS `create_time`,
       `ad`.`creator_id`           AS `creator_id`,
       `ad`.`last_modify_time`     AS `last_modify_time`,
       `ad`.`last_modifier_id`     AS `last_modifier_id`,
       `di`.`id`                   AS `device_id`,
       `di`.`no`                   AS `device_no`,
       `di`.`status`               AS `device_status`,
       `di`.`site_id`              AS `site_id`,
       `di`.`device_model_id`      AS `device_model_id`,
       `di`.`activation_time`      AS `activation_time`,
       `di`.`memo`                 AS `device_memo`,
       `di`.`create_time`          AS `device_create_time`,
       `di`.`creator_id`           AS `device_creator_id`,
       `di`.`last_modify_time`     AS `device_last_modify_time`,
       `di`.`last_modifier_id`     AS `device_last_modifier_id`,
       `di`.`num`                  AS `num`,
       `di`.`container_number`     AS `container_number`,
       `di`.`capacity`             AS `capacity`
from ((`sweeppayvendingcommon`.`dc_ad_device` `adr` left join `sweeppayvendingcommon`.`dc_ad` `ad` on ((`ad`.`id` = `adr`.`ad_id`)))
         left join `sweeppayvendingcommon`.`dc_device_info` `di` on ((`di`.`id` = `adr`.`device_id`)));

-- comment on column view_ad_device.id not supported: 主键ID

-- comment on column view_ad_device.no not supported: 广告编号

-- comment on column view_ad_device.name not supported: 素材名称

-- comment on column view_ad_device.file_type not supported: 素材文件类型

-- comment on column view_ad_device.path not supported: 文件路径

-- comment on column view_ad_device.size not supported: 文件大小

-- comment on column view_ad_device.effective_start_time not supported: 生效开始时间

-- comment on column view_ad_device.effective_end_time not supported: 生效结束时间

-- comment on column view_ad_device.status not supported: 状态 0 禁用 1 启用

-- comment on column view_ad_device.memo not supported: 备注

-- comment on column view_ad_device.mch_id not supported: 商户ID：为0或空时表示是系统平台机构，由类型为系统用户的用户添加及维护，不为0时则是由商户自行添加维护

-- comment on column view_ad_device.create_time not supported: 创建时间

-- comment on column view_ad_device.creator_id not supported: 创建者ID

-- comment on column view_ad_device.last_modify_time not supported: 最后修改时间

-- comment on column view_ad_device.last_modifier_id not supported: 最后修改者ID

-- comment on column view_ad_device.device_id not supported: 售货机信息唯一标识

-- comment on column view_ad_device.device_no not supported: 售货机编号

-- comment on column view_ad_device.device_status not supported: 状态 0 禁用 1 启用

-- comment on column view_ad_device.site_id not supported: 所在点位ID

-- comment on column view_ad_device.device_model_id not supported: 售货机型号ID

-- comment on column view_ad_device.activation_time not supported: 激活时间

-- comment on column view_ad_device.device_memo not supported: 备注

-- comment on column view_ad_device.device_create_time not supported: 创建时间

-- comment on column view_ad_device.device_creator_id not supported: 创建人ID

-- comment on column view_ad_device.device_last_modify_time not supported: 最后修改时间

-- comment on column view_ad_device.device_last_modifier_id not supported: 最后修改者ID

-- comment on column view_ad_device.num not supported: 货道数

-- comment on column view_ad_device.container_number not supported: 货柜数

-- comment on column view_ad_device.capacity not supported: 总容量


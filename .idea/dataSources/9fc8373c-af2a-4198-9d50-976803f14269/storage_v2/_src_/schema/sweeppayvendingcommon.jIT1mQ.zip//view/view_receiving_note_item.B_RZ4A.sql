create definer = root@`%` view view_receiving_note_item as
select `g`.`pinyin_code`                            AS `pinyin_code`,
       `gc`.`name`                                  AS `category_name`,
       `g`.`unit`                                   AS `stock_unit`,
       `rni`.`id`                                   AS `id`,
       `rni`.`warehouse_id`                         AS `warehouse_id`,
       `rni`.`warehouse_name`                       AS `warehouse_name`,
       `rni`.`receiving_note_id`                    AS `receiving_note_id`,
       `rni`.`receiving_note_num`                   AS `receiving_note_num`,
       `rni`.`order_date`                           AS `order_date`,
       `rni`.`goods_id`                             AS `goods_id`,
       `rni`.`goods_no`                             AS `goods_no`,
       `rni`.`goods_name`                           AS `goods_name`,
       `rni`.`price`                                AS `price`,
       `rni`.`unit`                                 AS `unit`,
       `rni`.`unit_id`                              AS `unit_id`,
       `rni`.`num`                                  AS `num`,
       `rni`.`total_price`                          AS `total_price`,
       `rni`.`memo`                                 AS `memo`,
       `rni`.`create_time`                          AS `create_time`,
       `rni`.`creator_id`                           AS `creator_id`,
       `u`.`name`                                   AS `creator_name`,
       `rni`.`produced_date`                        AS `produced_date`,
       `rni`.`surplus_num`                          AS `surplus_num`,
       `rni`.`transform_unit_id`                    AS `transform_unit_id`,
       `rni`.`transform_unit`                       AS `transform_unit`,
       `rni`.`transform_num`                        AS `transform_num`,
       `rni`.`transform_price`                      AS `transform_price`,
       `rni`.`mch_id`                               AS `mch_id`,
       ifnull(`s`.`total_stock_num`, 0)             AS `total_stock_num`,
       (select group_concat(concat(`gu`.`equivalent_value`, ',', `gu`.`unit_name`) separator ';')
        from `sweeppayvendingcommon`.`dc_goods_unit` `gu`
        where (`gu`.`goods_id` = `rni`.`goods_id`)) AS `unit_info`,
       `rn`.`status`                                AS `status`
from (((((`sweeppayvendingcommon`.`dc_receiving_note_item` `rni` left join `sweeppayvendingcommon`.`dc_receiving_note` `rn` on ((`rn`.`id` = `rni`.`receiving_note_id`))) left join `sweeppayvendingcommon`.`dc_goods` `g` on ((`g`.`id` = `rni`.`goods_id`))) left join `sweeppayvendingcommon`.`dc_goods_category` `gc` on ((`gc`.`id` = `g`.`goods_category_id`))) left join `sweeppayvendingcommon`.`dc_stock` `s` on ((
        (`s`.`goods_id` = `rni`.`goods_id`) and (`s`.`warehouse_id` = `rni`.`warehouse_id`))))
         left join `sweeppayvendingcommon`.`dc_user` `u` on ((`u`.`id` = `rni`.`creator_id`)));

-- comment on column view_receiving_note_item.pinyin_code not supported: 拼音码

-- comment on column view_receiving_note_item.category_name not supported: 分类名称

-- comment on column view_receiving_note_item.stock_unit not supported: 基本单位

-- comment on column view_receiving_note_item.id not supported: 主键ID

-- comment on column view_receiving_note_item.warehouse_id not supported: 仓库表ID

-- comment on column view_receiving_note_item.warehouse_name not supported: 仓库表名称

-- comment on column view_receiving_note_item.receiving_note_id not supported: 入库单ID

-- comment on column view_receiving_note_item.receiving_note_num not supported: 入库单编号

-- comment on column view_receiving_note_item.order_date not supported: 单据日期

-- comment on column view_receiving_note_item.goods_id not supported: 商品ID

-- comment on column view_receiving_note_item.goods_no not supported: 商品编号

-- comment on column view_receiving_note_item.goods_name not supported: 商品名称

-- comment on column view_receiving_note_item.price not supported: 进货价

-- comment on column view_receiving_note_item.unit not supported: 计量单位名称

-- comment on column view_receiving_note_item.unit_id not supported: 计量单位ID

-- comment on column view_receiving_note_item.num not supported: 数量

-- comment on column view_receiving_note_item.total_price not supported: 总价

-- comment on column view_receiving_note_item.memo not supported: 备注

-- comment on column view_receiving_note_item.create_time not supported: 创建时间

-- comment on column view_receiving_note_item.creator_id not supported: 创建人ID

-- comment on column view_receiving_note_item.produced_date not supported: 生产日期

-- comment on column view_receiving_note_item.surplus_num not supported: 当前剩余数量

-- comment on column view_receiving_note_item.transform_unit_id not supported: 转换后的单位ID

-- comment on column view_receiving_note_item.transform_unit not supported: 转化单位名称

-- comment on column view_receiving_note_item.transform_num not supported: 转换后的数量

-- comment on column view_receiving_note_item.transform_price not supported: 转化后的价格

-- comment on column view_receiving_note_item.mch_id not supported: 商户ID

-- comment on column view_receiving_note_item.status not supported: 状态：1、待审核 2、已审核  3、审核未通过


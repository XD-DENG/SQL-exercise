create
    definer = root@`%` procedure p_goods_del_flag(IN mchId varchar(32), IN goodsId varchar(32))
label:begin 
########################################
# 返回是否删除商品的标识 0 不能删除 1 可以删除
########################################
	declare flag int default 0 ;
	declare num int default 0 ;
	# 判断是否已产生入库记录
	select count(0) into num from dc_receiving_note_item where mch_id = mchId and goods_id = goodsId ;
	if num > 0 then 
			select 0 ;
			leave label ;
	end if ;
		# 判断是否已产生出库记录
	select count(0) into num from dc_delivery_note_item where mch_id = mchId and goods_id = goodsId ;
	if num > 0 then 
			select 0 ;
			leave label ;
	end if ;
	# 判断是否已绑定售货机
	select count(0) into num from dc_device_goods_info where mch_id = mchId and goods_id = goodsId ;
	if num > 0 then 
			select 0 ;
			leave label ;
	end if ;
  # 判断是否已绑定商品模板配置表
	select count(0) into num from dc_configure_template dt inner join dc_configure_template_detail ctd on dt.id = ctd.template_id
  where ctd.mch_id = mchId and ctd.goods_id = goodsId ;
	if num > 0 then 
			select 0 ;
			leave label ;
	end if ;
	select 1 ;
end
;


create definer = root@`%` view view_order as
select `o`.`id`                                                                                               AS `id`,
       `o`.`order_no`                                                                                         AS `order_no`,
       (select `d`.`no`
        from `sweeppayvendingcommon`.`dc_device_info` `d`
        where (`o`.`device_id` = `d`.`id`))                                                                   AS `device_id`,
       (select `c`.`name`
        from `sweeppayvendingcommon`.`dc_device_model` `c`
        where (`o`.`device_model_id` = `c`.`id`))                                                             AS `device_model_id`,
       `o`.`site_id`                                                                                          AS `site_id`,
       `o`.`site_name`                                                                                        AS `site_name`,
       `o`.`line_id`                                                                                          AS `line_id`,
       `o`.`line_name`                                                                                        AS `line_name`,
       `o`.`partition_id`                                                                                     AS `partition_id`,
       `o`.`partition_name`                                                                                   AS `partition_name`,
       `o`.`total_price`                                                                                      AS `total_price`,
       `o`.`actual_price`                                                                                     AS `actual_price`,
       `o`.`trade_type`                                                                                       AS `trade_type`,
       `o`.`pay_status`                                                                                       AS `pay_status`,
       `o`.`order_status`                                                                                     AS `order_status`,
       `o`.`shipment_status`                                                                                  AS `shipment_status`,
       `o`.`trade_no`                                                                                         AS `trade_no`,
       `o`.`refund_status`                                                                                    AS `refund_status`,
       `o`.`refund_time`                                                                                      AS `refund_time`,
       `o`.`refund_memo`                                                                                      AS `refund_memo`,
       `o`.`pay_time`                                                                                         AS `pay_time`,
       `o`.`create_time`                                                                                      AS `create_time`,
       `o`.`creator_id`                                                                                       AS `creator_id`,
       `o`.`mch_id`                                                                                           AS `mch_id`,
       `du`.`org_id`                                                                                          AS `org_id`,
       `org`.`relation_tree`                                                                                  AS `relation_tree`
from ((`sweeppayvendingcommon`.`dc_order` `o` left join `sweeppayvendingcommon`.`dc_user` `du` on ((`du`.`id` =
                                                                                                    (select `dm`.`admin_id`
                                                                                                     from `sweeppayvendingcommon`.`dc_merchant` `dm`
                                                                                                     where (`dm`.`id` = `o`.`mch_id`)))))
         left join `sweeppayvendingcommon`.`dc_org` `org` on ((`org`.`id` = `du`.`org_id`)));

-- comment on column view_order.id not supported: 订单ID

-- comment on column view_order.order_no not supported: 订单编号

-- comment on column view_order.site_id not supported: 所属点位ID

-- comment on column view_order.site_name not supported: 所属点位名称

-- comment on column view_order.line_id not supported: 所属线路ID

-- comment on column view_order.line_name not supported: 所属线路名称

-- comment on column view_order.partition_id not supported: 所属分区ID

-- comment on column view_order.partition_name not supported: 所属分区名称

-- comment on column view_order.total_price not supported: 交易总金额

-- comment on column view_order.actual_price not supported: 实际总金额

-- comment on column view_order.trade_type not supported: 交易方式 1 微信支付 2 支付宝 3 现金支付

-- comment on column view_order.pay_status not supported: 支付状态 1 已支付 0 未支付 2 支付失败

-- comment on column view_order.order_status not supported: 订单状态 0 未完成 1 已完成 2 退币异常单

-- comment on column view_order.shipment_status not supported: 出货状态 0 未出货 1 已出货 2 部分出货

-- comment on column view_order.trade_no not supported: 交易号

-- comment on column view_order.refund_status not supported: 退款状态

-- comment on column view_order.refund_time not supported: 退款时间

-- comment on column view_order.refund_memo not supported: 退款备注

-- comment on column view_order.pay_time not supported: 付款时间

-- comment on column view_order.create_time not supported: 创建时间

-- comment on column view_order.creator_id not supported: 创建人ID

-- comment on column view_order.mch_id not supported: 商户ID

-- comment on column view_order.org_id not supported: 组织机构ID

-- comment on column view_order.relation_tree not supported: 关系树，用“-”分割机构ID，如：1-2-3-


create
    definer = root@`%` procedure p_org_del_flag(IN orgId varchar(32))
label:begin 

		declare flag int default 2 ;
		declare num int default 0 ;
		select count(0) into num from dc_org where pid = orgId ;
		if num > 0 then 
				select 2 ;
				leave label ;
		end if ;
		select count(0) into num from dc_user where is_delete = 0 and org_id = orgId ;
		if num > 0 then 
				select 3 ;
				leave label ;
		end if ;
		select count(0) into num from dc_partition where org_id = orgId ;
		if num > 0 then 
				select 4 ;
				leave label ;
		end if ;
		select 1 ;
end
;


create definer = root@`%` view view_delivery_note_item as
select `dni`.`id`                                   AS `id`,
       `dni`.`warehouse_id`                         AS `warehouse_id`,
       `dni`.`warehouse_name`                       AS `warehouse_name`,
       `dni`.`delivery_note_id`                     AS `delivery_note_id`,
       `dni`.`delivery_note_num`                    AS `delivery_note_num`,
       `dni`.`order_date`                           AS `order_date`,
       `dni`.`goods_id`                             AS `goods_id`,
       `dni`.`goods_no`                             AS `goods_no`,
       `dni`.`goods_name`                           AS `goods_name`,
       `dni`.`price`                                AS `price`,
       `dni`.`cost_price`                           AS `cost_price`,
       `dni`.`sale_price`                           AS `sale_price`,
       `dni`.`unit_id`                              AS `unit_id`,
       `dni`.`unit`                                 AS `unit`,
       `dni`.`num`                                  AS `num`,
       `dni`.`total_price`                          AS `total_price`,
       `dni`.`memo`                                 AS `memo`,
       `dni`.`transform_unit_id`                    AS `transform_unit_id`,
       `dni`.`transform_unit`                       AS `transform_unit`,
       `dni`.`transform_num`                        AS `transform_num`,
       `dni`.`transform_price`                      AS `transform_price`,
       `dni`.`create_time`                          AS `create_time`,
       `dni`.`creator_id`                           AS `creator_id`,
       `dni`.`mch_id`                               AS `mch_id`,
       `g`.`pinyin_code`                            AS `pinyin_code`,
       `gc`.`name`                                  AS `category_name`,
       `g`.`unit`                                   AS `stock_unit`,
       `u`.`name`                                   AS `creator_name`,
       ifnull(`s`.`total_stock_num`, 0)             AS `total_stock_num`,
       (select group_concat(concat(`gu`.`equivalent_value`, ',', `gu`.`unit_name`) separator ';')
        from `sweeppayvendingcommon`.`dc_goods_unit` `gu`
        where (`gu`.`goods_id` = `dni`.`goods_id`)) AS `unit_info`
from (((((`sweeppayvendingcommon`.`dc_delivery_note_item` `dni` left join `sweeppayvendingcommon`.`dc_delivery_note` `dn` on ((`dn`.`id` = `dni`.`delivery_note_id`))) left join `sweeppayvendingcommon`.`dc_goods` `g` on ((`g`.`id` = `dni`.`goods_id`))) left join `sweeppayvendingcommon`.`dc_goods_category` `gc` on ((`gc`.`id` = `g`.`goods_category_id`))) left join `sweeppayvendingcommon`.`dc_stock` `s` on ((
        (`s`.`goods_id` = `dni`.`goods_id`) and (`s`.`warehouse_id` = `dni`.`warehouse_id`))))
         left join `sweeppayvendingcommon`.`dc_user` `u` on ((`u`.`id` = `dni`.`creator_id`)));

-- comment on column view_delivery_note_item.id not supported: 主键ID

-- comment on column view_delivery_note_item.warehouse_id not supported: 仓库表ID

-- comment on column view_delivery_note_item.warehouse_name not supported: 仓库表名称

-- comment on column view_delivery_note_item.delivery_note_id not supported: 出库单ID

-- comment on column view_delivery_note_item.delivery_note_num not supported: 出库单编号

-- comment on column view_delivery_note_item.order_date not supported: 单据日期

-- comment on column view_delivery_note_item.goods_id not supported: 商品ID

-- comment on column view_delivery_note_item.goods_no not supported: 商品编号

-- comment on column view_delivery_note_item.goods_name not supported: 商品名称

-- comment on column view_delivery_note_item.price not supported: 进货价

-- comment on column view_delivery_note_item.cost_price not supported: 成本价

-- comment on column view_delivery_note_item.sale_price not supported: 销售价

-- comment on column view_delivery_note_item.unit_id not supported: 计量单位ID

-- comment on column view_delivery_note_item.unit not supported: 计量单位名称

-- comment on column view_delivery_note_item.num not supported: 数量

-- comment on column view_delivery_note_item.total_price not supported: 总价

-- comment on column view_delivery_note_item.memo not supported: 备注

-- comment on column view_delivery_note_item.transform_unit_id not supported: 转换后的单位ID

-- comment on column view_delivery_note_item.transform_unit not supported: 转化单位名称

-- comment on column view_delivery_note_item.transform_num not supported: 转换后的数量

-- comment on column view_delivery_note_item.transform_price not supported: 转化后的价格

-- comment on column view_delivery_note_item.create_time not supported: 创建时间

-- comment on column view_delivery_note_item.creator_id not supported: 创建人ID

-- comment on column view_delivery_note_item.mch_id not supported: 商户ID

-- comment on column view_delivery_note_item.pinyin_code not supported: 拼音码

-- comment on column view_delivery_note_item.category_name not supported: 分类名称

-- comment on column view_delivery_note_item.stock_unit not supported: 基本单位


create definer = root@`%` view view_device_info_monitor as
select `dm`.`id`                             AS `id`,
       `di`.`id`                             AS `device_id`,
       ifnull(`dm`.`network_status`, '0')    AS `network_status`,
       ifnull(`dm`.`hardware_status`, '1')   AS `hardware_status`,
       ifnull(`dm`.`is_less_coin`, '0')      AS `is_less_coin`,
       ifnull(`dm`.`is_more_banknotes`, '0') AS `is_more_banknotes`,
       `dm`.`memo`                           AS `memo`,
       `di`.`mch_id`                         AS `mch_id`,
       `dm`.`create_time`                    AS `create_time`,
       `di`.`no`                             AS `no`,
       `di`.`status`                         AS `status`,
       `di`.`site_id`                        AS `site_id`,
       `di`.`device_model_id`                AS `device_model_id`,
       `di`.`activation_time`                AS `activation_time`,
       `di`.`memo`                           AS `device_memo`,
       `di`.`create_time`                    AS `device_create_time`,
       `di`.`creator_id`                     AS `creator_id`,
       `di`.`last_modify_time`               AS `last_modify_time`,
       `di`.`last_modifier_id`               AS `last_modifier_id`,
       `di`.`num`                            AS `num`,
       `di`.`container_number`               AS `container_number`,
       `di`.`capacity`                       AS `capacity`,
       `ds`.`name`                           AS `site_name`,
       `ds`.`address`                        AS `address`,
       `ds`.`partition_id`                   AS `partition_id`,
       ifnull(`p`.`org_id`, '')              AS `org_id`,
       `ds`.`line_id`                        AS `line_id`
from (((`sweeppayvendingcommon`.`dc_device_info` `di` left join `sweeppayvendingcommon`.`dc_device_monitor` `dm` on ((`dm`.`device_id` = `di`.`id`))) left join `sweeppayvendingcommon`.`dc_site` `ds` on ((`ds`.`id` = `di`.`site_id`)))
         left join `sweeppayvendingcommon`.`dc_partition` `p`
                   on (((`di`.`mch_id` = `p`.`mch_id`) and (`p`.`id` = `ds`.`partition_id`))));

-- comment on column view_device_info_monitor.id not supported: 主键唯一标识

-- comment on column view_device_info_monitor.device_id not supported: 售货机信息唯一标识

-- comment on column view_device_info_monitor.memo not supported: 备注

-- comment on column view_device_info_monitor.mch_id not supported: 商户ID

-- comment on column view_device_info_monitor.create_time not supported: 创建时间

-- comment on column view_device_info_monitor.no not supported: 售货机编号

-- comment on column view_device_info_monitor.status not supported: 状态 0 禁用 1 启用

-- comment on column view_device_info_monitor.site_id not supported: 所在点位ID

-- comment on column view_device_info_monitor.device_model_id not supported: 售货机型号ID

-- comment on column view_device_info_monitor.activation_time not supported: 激活时间

-- comment on column view_device_info_monitor.device_memo not supported: 备注

-- comment on column view_device_info_monitor.device_create_time not supported: 创建时间

-- comment on column view_device_info_monitor.creator_id not supported: 创建人ID

-- comment on column view_device_info_monitor.last_modify_time not supported: 最后修改时间

-- comment on column view_device_info_monitor.last_modifier_id not supported: 最后修改者ID

-- comment on column view_device_info_monitor.num not supported: 货道数

-- comment on column view_device_info_monitor.container_number not supported: 货柜数

-- comment on column view_device_info_monitor.capacity not supported: 总容量

-- comment on column view_device_info_monitor.site_name not supported: 点位名称

-- comment on column view_device_info_monitor.address not supported: 详细地址

-- comment on column view_device_info_monitor.partition_id not supported: 所在分区ID

-- comment on column view_device_info_monitor.line_id not supported: 所属线路ID


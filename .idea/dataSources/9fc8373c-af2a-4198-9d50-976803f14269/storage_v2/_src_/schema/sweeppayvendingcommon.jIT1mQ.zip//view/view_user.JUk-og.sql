create definer = root@`%` view view_user as
select `u`.`id`                             AS `id`,
       `u`.`type`                           AS `type`,
       `u`.`name`                           AS `name`,
       `u`.`login_name`                     AS `login_name`,
       `u`.`mobile`                         AS `mobile`,
       `u`.`password`                       AS `password`,
       `u`.`avatar_url`                     AS `avatar_url`,
       `u`.`org_id`                         AS `org_id`,
       `u`.`available`                      AS `available`,
       `u`.`is_delete`                      AS `is_delete`,
       `u`.`last_login_ip`                  AS `last_login_ip`,
       `u`.`last_login_time`                AS `last_login_time`,
       `u`.`create_time`                    AS `create_time`,
       `u`.`creator_id`                     AS `creator_id`,
       `u`.`last_modify_time`               AS `last_modify_time`,
       `u`.`last_modifier_id`               AS `last_modifier_id`,
       `o`.`name`                           AS `org_name`,
       `o`.`relation_tree`                  AS `relation_tree`,
       (select group_concat(`r`.`name` separator ',') AS `roles`
        from (`sweeppayvendingcommon`.`dc_user_role_rela` `urr`
                 join `sweeppayvendingcommon`.`dc_role` `r` on ((`r`.`id` = `urr`.`role_id`)))
        where (`urr`.`user_id` = `u`.`id`)) AS `roles`
from (`sweeppayvendingcommon`.`dc_user` `u`
         left join `sweeppayvendingcommon`.`dc_org` `o` on ((`o`.`id` = `u`.`org_id`)));

-- comment on column view_user.type not supported: 用户类型：1、系统用户 2、商户员工

-- comment on column view_user.mobile not supported: 手机号

-- comment on column view_user.avatar_url not supported: 头像地址

-- comment on column view_user.org_id not supported: 组织机构ID

-- comment on column view_user.available not supported: 是否可用：1、可用 0、不可用

-- comment on column view_user.is_delete not supported: 是否删除

-- comment on column view_user.last_login_ip not supported: 最后登录IP

-- comment on column view_user.last_login_time not supported: 最后登录时间

-- comment on column view_user.create_time not supported: 创建时间

-- comment on column view_user.creator_id not supported: 创建者ID

-- comment on column view_user.last_modify_time not supported: 最后修改时间

-- comment on column view_user.last_modifier_id not supported: 最后修改者ID

-- comment on column view_user.org_name not supported: 名称

-- comment on column view_user.relation_tree not supported: 关系树，用“-”分割机构ID，如：1-2-3-


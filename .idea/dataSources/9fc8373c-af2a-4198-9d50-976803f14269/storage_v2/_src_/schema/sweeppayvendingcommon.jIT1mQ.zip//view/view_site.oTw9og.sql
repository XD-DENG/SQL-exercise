create definer = root@`%` view view_site as
select `s`.`id`                                                                               AS `id`,
       `s`.`name`                                                                             AS `name`,
       `s`.`status`                                                                           AS `status`,
       `s`.`partition_id`                                                                     AS `partition_id`,
       `s`.`line_id`                                                                          AS `line_id`,
       (select `l`.`name`
        from `sweeppayvendingcommon`.`dc_line` `l`
        where ((`l`.`mch_id` = `s`.`mch_id`) and (`s`.`line_id` = `l`.`id`)))                 AS `line_name`,
       `s`.`location_address`                                                                 AS `location_address`,
       `s`.`address`                                                                          AS `address`,
       `s`.`longitude`                                                                        AS `longitude`,
       `s`.`latitude`                                                                         AS `latitude`,
       `s`.`provice_id`                                                                       AS `provice_id`,
       concat(ifnull((select `d`.`name`
                      from `sweeppayvendingcommon`.`dc_district` `d`
                      where ((`d`.`treelevel` = '1') and (`d`.`id` = `s`.`provice_id`))), ''), ifnull((select `d`.`name`
                                                                                                       from `sweeppayvendingcommon`.`dc_district` `d`
                                                                                                       where ((`d`.`treelevel` = '2') and (`d`.`id` = `s`.`city_id`))),
                                                                                                      ''),
              ifnull((select `d`.`name`
                      from `sweeppayvendingcommon`.`dc_district` `d`
                      where ((`d`.`treelevel` = '3') and (`d`.`id` = `s`.`county_id`))), '')) AS `district_name`,
       `s`.`city_id`                                                                          AS `city_id`,
       `s`.`county_id`                                                                        AS `county_id`,
       `s`.`mch_id`                                                                           AS `mch_id`,
       `s`.`memo`                                                                             AS `memo`,
       `s`.`creator_id`                                                                       AS `creator_id`,
       `s`.`create_time`                                                                      AS `create_time`,
       `s`.`last_modifier_id`                                                                 AS `last_modifier_id`,
       `s`.`last_modify_time`                                                                 AS `last_modify_time`,
       `p`.`name`                                                                             AS `partition_name`,
       `dor`.`relation_tree`                                                                  AS `relation_tree`,
       `p`.`org_id`                                                                           AS `org_id`
from ((`sweeppayvendingcommon`.`dc_site` `s` left join `sweeppayvendingcommon`.`dc_partition` `p` on (((`p`.`mch_id` = `s`.`mch_id`) and (`s`.`partition_id` = `p`.`id`))))
         left join `sweeppayvendingcommon`.`dc_org` `dor` on ((`dor`.`id` = `p`.`org_id`)))
where ((1 = 1) and exists(select 1
                          from `sweeppayvendingcommon`.`dc_org` `o`
                          where ((`o`.`relation_tree` like concat(`o`.`relation_tree`, '%')) and
                                 (`p`.`org_id` = `o`.`id`))));

-- comment on column view_site.id not supported: 点位信息唯一标识

-- comment on column view_site.name not supported: 点位名称

-- comment on column view_site.status not supported: 状态 0 禁用 1 启用

-- comment on column view_site.partition_id not supported: 所在分区ID

-- comment on column view_site.line_id not supported: 所属线路ID

-- comment on column view_site.location_address not supported: 摆放位置

-- comment on column view_site.address not supported: 详细地址

-- comment on column view_site.longitude not supported: 经度

-- comment on column view_site.latitude not supported: 纬度

-- comment on column view_site.provice_id not supported: 所属省份

-- comment on column view_site.city_id not supported: 所属市区ID

-- comment on column view_site.county_id not supported: 所属区县ID

-- comment on column view_site.mch_id not supported: 商户ID

-- comment on column view_site.memo not supported: 备注

-- comment on column view_site.creator_id not supported: 创建人ID

-- comment on column view_site.create_time not supported: 创建时间

-- comment on column view_site.last_modifier_id not supported: 最后修改者ID

-- comment on column view_site.last_modify_time not supported: 最后修改时间

-- comment on column view_site.partition_name not supported: 点位分区名称

-- comment on column view_site.relation_tree not supported: 关系树，用“-”分割机构ID，如：1-2-3-

-- comment on column view_site.org_id not supported: 所属机构ID


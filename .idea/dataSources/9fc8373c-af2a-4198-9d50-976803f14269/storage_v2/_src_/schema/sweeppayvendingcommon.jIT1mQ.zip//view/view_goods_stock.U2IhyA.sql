create definer = root@`%` view view_goods_stock as
select `g`.`id`                              AS `id`,
       `g`.`name`                            AS `name`,
       `g`.`barcode`                         AS `barcode`,
       `g`.`code`                            AS `code`,
       `g`.`gen_no`                          AS `genNo`,
       `g`.`is_auto`                         AS `isAuto`,
       `g`.`pinyin_code`                     AS `pinyinCode`,
       `g`.`purchase_price`                  AS `purchasePrice`,
       `g`.`cost_price`                      AS `costPrice`,
       `g`.`sales_price`                     AS `salesPrice`,
       `g`.`picture`                         AS `picture`,
       `g`.`memo`                            AS `memo`,
       `g`.`status`                          AS `status`,
       `g`.`unit`                            AS `unit`,
       `g`.`goods_category_id`               AS `goodsCategoryId`,
       `g`.`expiration_date`                 AS `expirationDate`,
       `g`.`specification`                   AS `specification`,
       `g`.`create_time`                     AS `create_time`,
       `g`.`creator_id`                      AS `creatorId`,
       `g`.`mch_id`                          AS `mchId`,
       `g`.`last_modify_time`                AS `lastModifyTime`,
       `g`.`last_modifier_id`                AS `lastModifierId`,
       ifnull(sum(`s`.`total_stock_num`), 0) AS `totalStockNum`,
       `s`.`warehouse_id`                    AS `warehouseId`,
       `s`.`warehouse_name`                  AS `warehouseName`,
       `gc`.`name`                           AS `categoryName`,
       (select group_concat(concat(`gu`.`equivalent_value`, ',', `gu`.`unit_name`) separator ';')
        from `sweeppayvendingcommon`.`dc_goods_unit` `gu`
        where (`gu`.`goods_id` = `g`.`id`))  AS `unitInfo`
from ((`sweeppayvendingcommon`.`dc_goods` `g` left join `sweeppayvendingcommon`.`dc_stock` `s` on ((`s`.`goods_id` = `g`.`id`)))
         left join `sweeppayvendingcommon`.`dc_goods_category` `gc` on ((`gc`.`id` = `g`.`goods_category_id`)))
group by `g`.`id`;

-- comment on column view_goods_stock.id not supported: 商品表ID

-- comment on column view_goods_stock.name not supported: 名称

-- comment on column view_goods_stock.barcode not supported: 条形码

-- comment on column view_goods_stock.code not supported: 编号

-- comment on column view_goods_stock.genNo not supported: 自动生成编号

-- comment on column view_goods_stock.isAuto not supported: 编号是否是自动生成 1 是 0 否

-- comment on column view_goods_stock.pinyinCode not supported: 拼音码

-- comment on column view_goods_stock.purchasePrice not supported: 进货价

-- comment on column view_goods_stock.costPrice not supported: 成本价

-- comment on column view_goods_stock.salesPrice not supported: 销售价

-- comment on column view_goods_stock.picture not supported: 图片

-- comment on column view_goods_stock.memo not supported: 简介

-- comment on column view_goods_stock.status not supported: 状态0删除 1 正常

-- comment on column view_goods_stock.unit not supported: 基本单位

-- comment on column view_goods_stock.goodsCategoryId not supported: 分类ID

-- comment on column view_goods_stock.expirationDate not supported: 保质期（以天计算）

-- comment on column view_goods_stock.specification not supported: 规格

-- comment on column view_goods_stock.create_time not supported: 创建时间

-- comment on column view_goods_stock.creatorId not supported: 创建人ID

-- comment on column view_goods_stock.mchId not supported: 商户ID

-- comment on column view_goods_stock.lastModifyTime not supported: 最后修改时间

-- comment on column view_goods_stock.lastModifierId not supported: 最后修改者ID

-- comment on column view_goods_stock.warehouseId not supported: 仓库表ID

-- comment on column view_goods_stock.warehouseName not supported: 仓库表名称

-- comment on column view_goods_stock.categoryName not supported: 分类名称


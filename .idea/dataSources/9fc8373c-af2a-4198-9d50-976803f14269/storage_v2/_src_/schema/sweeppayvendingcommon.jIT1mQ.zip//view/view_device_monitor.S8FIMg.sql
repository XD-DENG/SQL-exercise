create definer = root@`%` view view_device_monitor as
select `t`.`device_id`                                                                AS `device_id`,
       `t`.`device_no`                                                                AS `device_no`,
       `t`.`status`                                                                   AS `status`,
       `t`.`partition_id`                                                             AS `partition_id`,
       `t`.`org_id`                                                                   AS `org_id`,
       `t`.`line_id`                                                                  AS `line_id`,
       `t`.`site_id`                                                                  AS `site_id`,
       `t`.`site_name`                                                                AS `site_name`,
       `t`.`model_id`                                                                 AS `model_id`,
       `t`.`model_name`                                                               AS `model_name`,
       `t`.`mch_id`                                                                   AS `mch_id`,
       `t`.`capacity`                                                                 AS `capacity`,
       `t`.`stock_num`                                                                AS `stock_num`,
       `t`.`num`                                                                      AS `num`,
       `t`.`empty_num`                                                                AS `empty_num`,
       `t`.`good_num`                                                                 AS `good_num`,
       `t`.`empty_good`                                                               AS `empty_good`,
       concat(format(ifnull(((`t`.`stock_num` / `t`.`capacity`) * 100), 0), 2), '%')  AS `inventory_ratio`,
       concat(format(ifnull(((`t`.`empty_num` / `t`.`num`) * 100), 0), 2), '%')       AS `empty_ratio`,
       concat(format(ifnull(((`t`.`empty_good` / `t`.`good_num`) * 100), 0), 2), '%') AS `good_ratio`
from (select `vdi`.`id`                                             AS `device_id`,
             `vdi`.`no`                                             AS `device_no`,
             `vdi`.`status`                                         AS `status`,
             `vdi`.`partition_id`                                   AS `partition_id`,
             `vdi`.`org_id`                                         AS `org_id`,
             `vdi`.`line_id`                                        AS `line_id`,
             `vdi`.`site_id`                                        AS `site_id`,
             `vdi`.`site_name`                                      AS `site_name`,
             `vdi`.`model_id`                                       AS `model_id`,
             `vdi`.`model_name`                                     AS `model_name`,
             `vdi`.`mch_id`                                         AS `mch_id`,
             `vdi`.`capacity`                                       AS `capacity`,
             format(ifnull(sum(`dgi`.`stock_num`), 0), 0)           AS `stock_num`,
             `vdi`.`num`                                            AS `num`,
             (`vdi`.`num` - sum(if((`dgi`.`stock_num` > 0), 1, 0))) AS `empty_num`,
             ifnull((select count(distinct `dgi1`.`goods_id`)
                     from `sweeppayvendingcommon`.`dc_device_goods_info` `dgi1`
                     where ((`dgi1`.`device_id` = `vdi`.`id`) and (`dgi1`.`mch_id` = `vdi`.`mch_id`))
                     group by `dgi1`.`device_id`), 0)               AS `good_num`,
             ifnull((select count(`d2`.`goods_id`)
                     from (select `dgi2`.`mch_id`    AS `mch_id`,
                                  `dgi2`.`device_id` AS `device_id`,
                                  `dgi2`.`goods_id`  AS `goods_id`
                           from `sweeppayvendingcommon`.`dc_device_goods_info` `dgi2`
                           group by `dgi2`.`mch_id`, `dgi2`.`device_id`, `dgi2`.`goods_id`
                           having (sum(`dgi2`.`stock_num`) = 0)) `d2`
                     where ((`d2`.`mch_id` = `vdi`.`mch_id`) and (`d2`.`device_id` = `vdi`.`id`))
                     group by `d2`.`device_id`), 0)                 AS `empty_good`
      from (`sweeppayvendingcommon`.`view_device_info` `vdi`
               left join `sweeppayvendingcommon`.`dc_device_goods_info` `dgi`
                         on (((`vdi`.`id` = `dgi`.`device_id`) and (`vdi`.`mch_id` = `dgi`.`mch_id`))))
      group by `vdi`.`id`) `t`;

-- comment on column view_device_monitor.device_id not supported: 售货机信息唯一标识

-- comment on column view_device_monitor.device_no not supported: 售货机编号

-- comment on column view_device_monitor.status not supported: 状态 0 禁用 1 启用

-- comment on column view_device_monitor.site_id not supported: 所在点位ID

-- comment on column view_device_monitor.mch_id not supported: 商户ID

-- comment on column view_device_monitor.capacity not supported: 总容量

-- comment on column view_device_monitor.num not supported: 货道数


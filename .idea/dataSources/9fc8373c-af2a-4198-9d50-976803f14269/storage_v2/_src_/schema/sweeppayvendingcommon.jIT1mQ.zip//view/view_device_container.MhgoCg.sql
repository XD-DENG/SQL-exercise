create definer = root@`%` view view_device_container as
select `dc`.`id`                  AS `id`,
       `dc`.`name`                AS `name`,
       `dc`.`status`              AS `status`,
       `dc`.`type`                AS `type`,
       `dc`.`manufacturer_id`     AS `manufacturer_id`,
       `dc`.`capacity`            AS `capacity`,
       `dc`.`row_number`          AS `row_number`,
       `dc`.`max_cols_number`     AS `max_cols_number`,
       `dc`.`memo`                AS `memo`,
       `dc`.`mch_id`              AS `mch_id`,
       `dc`.`create_time`         AS `create_time`,
       `dc`.`creator_id`          AS `creator_id`,
       `dc`.`last_modify_time`    AS `last_modify_time`,
       `dc`.`last_modifier_id`    AS `last_modifier_id`,
       `dc`.`max_shipment_number` AS `max_shipment_number`,
       `dmcr`.`device_model_id`   AS `device_model_id`
from (`sweeppayvendingcommon`.`dc_device_container` `dc`
         left join `sweeppayvendingcommon`.`dc_device_model_container_rela` `dmcr`
                   on ((`dc`.`id` = `dmcr`.`device_container_id`)))
group by `dc`.`id`;

-- comment on column view_device_container.id not supported: 货柜机型唯一标识

-- comment on column view_device_container.name not supported: 货柜型号

-- comment on column view_device_container.status not supported: 状态 0 禁用 1 启用

-- comment on column view_device_container.type not supported: 货柜类型 1弹簧机 2格子机

-- comment on column view_device_container.manufacturer_id not supported: 生产厂家

-- comment on column view_device_container.capacity not supported: 货柜容量

-- comment on column view_device_container.`row_number` not supported: 货道行数

-- comment on column view_device_container.max_cols_number not supported: 最大列数

-- comment on column view_device_container.memo not supported: 备注

-- comment on column view_device_container.mch_id not supported: 商户ID

-- comment on column view_device_container.create_time not supported: 创建时间

-- comment on column view_device_container.creator_id not supported: 创建人ID

-- comment on column view_device_container.last_modify_time not supported: 最后修改时间

-- comment on column view_device_container.last_modifier_id not supported: 最后修改者ID

-- comment on column view_device_container.max_shipment_number not supported: 最大出货数量

-- comment on column view_device_container.device_model_id not supported: 售货机型号ID


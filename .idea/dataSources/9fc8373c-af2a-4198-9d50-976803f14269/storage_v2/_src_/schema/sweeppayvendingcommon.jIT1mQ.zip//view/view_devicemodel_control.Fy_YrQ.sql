create definer = root@`%` view view_devicemodel_control as
select `dm`.`id`                               AS `id`,
       `dm`.`name`                             AS `name`,
       `dm`.`status`                           AS `status`,
       `dm`.`control_id`                       AS `control_id`,
       `dm`.`images`                           AS `images`,
       `dm`.`memo`                             AS `memo`,
       `dm`.`mch_id`                           AS `mch_id`,
       `dm`.`create_time`                      AS `create_time`,
       `dm`.`creator_id`                       AS `creator_id`,
       `dm`.`last_modify_time`                 AS `last_modify_time`,
       `dm`.`last_modifier_id`                 AS `last_modifier_id`,
       group_concat(`dc`.`name` separator ',') AS `leftName`,
       `c`.`name`                              AS `controlName`,
       `c`.`factory_id`                        AS `factory_id`
from (((`sweeppayvendingcommon`.`dc_device_model` `dm` left join `sweeppayvendingcommon`.`dc_device_model_container_rela` `dmcr` on ((`dmcr`.`device_model_id` = `dm`.`id`))) left join `sweeppayvendingcommon`.`dc_device_container` `dc` on ((`dmcr`.`device_container_id` = `dc`.`id`)))
         left join `sweeppayvendingcommon`.`dc_device_control` `c` on ((`c`.`id` = `dm`.`control_id`)))
group by `dm`.`id`;

-- comment on column view_devicemodel_control.id not supported: 售货机型号唯一标识

-- comment on column view_devicemodel_control.name not supported: 售货机型号名称

-- comment on column view_devicemodel_control.status not supported: 状态 0 禁用 1 启用

-- comment on column view_devicemodel_control.control_id not supported: 控制端型号ID

-- comment on column view_devicemodel_control.images not supported: 图片，多张图片以‘，’形式分开

-- comment on column view_devicemodel_control.memo not supported: 备注

-- comment on column view_devicemodel_control.mch_id not supported: 商户ID

-- comment on column view_devicemodel_control.create_time not supported: 创建时间

-- comment on column view_devicemodel_control.creator_id not supported: 创建人ID

-- comment on column view_devicemodel_control.last_modify_time not supported: 最后修改时间

-- comment on column view_devicemodel_control.last_modifier_id not supported: 最后修改者ID

-- comment on column view_devicemodel_control.controlName not supported: 控制端型号名称

-- comment on column view_devicemodel_control.factory_id not supported: 适配厂家


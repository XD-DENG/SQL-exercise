create definer = root@`%` view view_merchant as
select `m`.`id`               AS `id`,
       `m`.`name`             AS `name`,
       `m`.`short_name`       AS `short_name`,
       `m`.`org_code`         AS `org_code`,
       `m`.`phone`            AS `phone`,
       `m`.`fax`              AS `fax`,
       `m`.`zipcode`          AS `zipcode`,
       `m`.`address`          AS `address`,
       `m`.`linkman`          AS `linkman`,
       `m`.`mobile`           AS `mobile`,
       `m`.`admin_id`         AS `admin_id`,
       `m`.`available`        AS `available`,
       `m`.`create_time`      AS `create_time`,
       `m`.`creator_id`       AS `creator_id`,
       `m`.`last_modify_time` AS `last_modify_time`,
       `m`.`last_modifier_id` AS `last_modifier_id`,
       `u`.`login_name`       AS `login_name`
from (`sweeppayvendingcommon`.`dc_merchant` `m`
         left join `sweeppayvendingcommon`.`dc_user` `u` on ((`m`.`admin_id` = `u`.`id`)))
where (`m`.`id` <> '0');

-- comment on column view_merchant.id not supported: 主键ID

-- comment on column view_merchant.name not supported: 名称

-- comment on column view_merchant.short_name not supported: 简称

-- comment on column view_merchant.org_code not supported: 组织机构代码

-- comment on column view_merchant.phone not supported: 电话

-- comment on column view_merchant.fax not supported: 传真

-- comment on column view_merchant.zipcode not supported: 邮编

-- comment on column view_merchant.address not supported: 地址

-- comment on column view_merchant.linkman not supported: 联系人

-- comment on column view_merchant.mobile not supported: 联系电话

-- comment on column view_merchant.admin_id not supported: 管理员ID

-- comment on column view_merchant.available not supported: 是否可用：1、可用 0、不可用

-- comment on column view_merchant.create_time not supported: 创建时间

-- comment on column view_merchant.creator_id not supported: 创建者ID

-- comment on column view_merchant.last_modify_time not supported: 最后修改时间

-- comment on column view_merchant.last_modifier_id not supported: 最后修改者ID


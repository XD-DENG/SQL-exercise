create definer = root@`%` view view_order_detail as
select `a`.`order_no`            AS `order_no`,
       `a`.`trade_no`            AS `trade_no`,
       `b`.`goods_name`          AS `goods_name`,
       `c`.`code`                AS `CODE`,
       `a`.`pay_time`            AS `pay_time`,
       `a`.`trade_type`          AS `trade_type`,
       `a`.`actual_price`        AS `actual_price`,
       `b`.`price`               AS `price`,
       `b`.`num`                 AS `num`,
       `b`.`actual_shipment_num` AS `actual_shipment_num`,
       `b`.`row`                 AS `ROW`,
       `b`.`col`                 AS `col`,
       `a`.`pay_status`          AS `pay_type`,
       `a`.`shipment_status`     AS `shipment_status`,
       `a`.`refund_status`       AS `refund_status`,
       `a`.`device_id`           AS `device_id`,
       `a`.`site_name`           AS `site_name`,
       `a`.`partition_name`      AS `partition_name`,
       `a`.`line_name`           AS `line_name`,
       `a`.`device_model_id`     AS `device_model_id`,
       `a`.`mch_id`              AS `mch_id`,
       `a`.`create_time`         AS `create_time`,
       `b`.`id`                  AS `order_detail_id`,
       `a`.`id`                  AS `order_id`,
       `b`.`refund_status`       AS `detail_refund_status`,
       `a`.`refund_price`        AS `refund_price`,
       `a`.`refund_memo`         AS `refund_memo`,
       `a`.`coin_price`          AS `coin_price`
from ((`sweeppayvendingcommon`.`dc_order` `a` join `sweeppayvendingcommon`.`dc_order_detail` `b` on ((`a`.`id` = `b`.`order_id`)))
         left join `sweeppayvendingcommon`.`dc_goods` `c` on ((`b`.`goods_id` = `c`.`id`)))
where (((`a`.`pay_status` = '1') and (`a`.`shipment_status` = '0')) or (`a`.`order_status` = '2') or
       (`a`.`shipment_status` = '2') or (`b`.`num` > `b`.`actual_shipment_num`));

-- comment on column view_order_detail.order_no not supported: 订单编号

-- comment on column view_order_detail.trade_no not supported: 交易号

-- comment on column view_order_detail.goods_name not supported: 商品名称

-- comment on column view_order_detail.CODE not supported: 编号

-- comment on column view_order_detail.pay_time not supported: 付款时间

-- comment on column view_order_detail.trade_type not supported: 交易方式 1 微信支付 2 支付宝 3 现金支付

-- comment on column view_order_detail.actual_price not supported: 实际总金额

-- comment on column view_order_detail.price not supported: 商品价格

-- comment on column view_order_detail.num not supported: 数量

-- comment on column view_order_detail.actual_shipment_num not supported: 实际出货数量

-- comment on column view_order_detail.ROW not supported: 货道行号

-- comment on column view_order_detail.col not supported: 货道列号

-- comment on column view_order_detail.pay_type not supported: 支付状态 1 已支付 0 未支付 2 支付失败

-- comment on column view_order_detail.shipment_status not supported: 出货状态 0 未出货 1 已出货 2 部分出货

-- comment on column view_order_detail.refund_status not supported: 退款状态

-- comment on column view_order_detail.device_id not supported: 售货机ID

-- comment on column view_order_detail.site_name not supported: 所属点位名称

-- comment on column view_order_detail.partition_name not supported: 所属分区名称

-- comment on column view_order_detail.line_name not supported: 所属线路名称

-- comment on column view_order_detail.device_model_id not supported: 售货机型号

-- comment on column view_order_detail.mch_id not supported: 商户ID

-- comment on column view_order_detail.create_time not supported: 创建时间

-- comment on column view_order_detail.order_detail_id not supported: 订单明细ID

-- comment on column view_order_detail.order_id not supported: 订单ID

-- comment on column view_order_detail.detail_refund_status not supported: 退款状态 1 已退款 

-- comment on column view_order_detail.refund_price not supported: 退款金额

-- comment on column view_order_detail.refund_memo not supported: 退款备注

-- comment on column view_order_detail.coin_price not supported: 投币金额


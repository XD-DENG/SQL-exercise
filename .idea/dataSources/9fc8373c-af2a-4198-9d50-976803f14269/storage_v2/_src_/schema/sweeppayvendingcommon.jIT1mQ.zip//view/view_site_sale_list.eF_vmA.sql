create definer = root@`%` view view_site_sale_list as
select `s`.`id`                                                                    AS `id`,
       `s`.`name`                                                                  AS `name`,
       `s`.`status`                                                                AS `status`,
       `s`.`partition_id`                                                          AS `partition_id`,
       (select `p`.`name`
        from `sweeppayvendingcommon`.`dc_partition` `p`
        where ((`p`.`mch_id` = `s`.`mch_id`) and (`p`.`id` = `s`.`partition_id`))) AS `partition_name`,
       `s`.`line_id`                                                               AS `line_id`,
       (select `l`.`name`
        from `sweeppayvendingcommon`.`dc_line` `l`
        where ((`l`.`mch_id` = `s`.`mch_id`) and (`l`.`id` = `s`.`line_id`)))      AS `line_name`,
       `s`.`mch_id`                                                                AS `mch_id`,
       format(ifnull(sum(`o`.`actual_price`), 0), 2)                               AS `actual_total_money`,
       sum(ifnull(`od`.`num`, 0))                                                  AS `buy_total_num`,
       sum(ifnull(`od`.`actual_shipment_num`, 0))                                  AS `actual_total_num`
from ((`sweeppayvendingcommon`.`dc_site` `s` left join `sweeppayvendingcommon`.`dc_order` `o` on ((
        (`o`.`mch_id` = `s`.`mch_id`) and (`s`.`id` = `o`.`site_id`) and (`o`.`shipment_status` = '1') and
        (`o`.`order_status` = '1') and (`o`.`pay_status` = '1'))))
         left join `sweeppayvendingcommon`.`dc_order_detail` `od`
                   on (((`od`.`mch_id` = `s`.`mch_id`) and (`o`.`id` = `od`.`order_id`))))
group by `s`.`mch_id`, `s`.`id`;

-- comment on column view_site_sale_list.id not supported: 点位信息唯一标识

-- comment on column view_site_sale_list.name not supported: 点位名称

-- comment on column view_site_sale_list.status not supported: 状态 0 禁用 1 启用

-- comment on column view_site_sale_list.partition_id not supported: 所在分区ID

-- comment on column view_site_sale_list.line_id not supported: 所属线路ID

-- comment on column view_site_sale_list.mch_id not supported: 商户ID


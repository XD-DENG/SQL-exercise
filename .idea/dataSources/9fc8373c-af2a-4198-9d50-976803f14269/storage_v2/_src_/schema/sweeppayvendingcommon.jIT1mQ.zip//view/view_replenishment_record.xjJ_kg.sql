create definer = root@`%` view view_replenishment_record as
select `a`.`id`                                                                                         AS `id`,
       `a`.`device_id`                                                                                  AS `device_id`,
       `a`.`num`                                                                                        AS `num`,
       `a`.`mch_id`                                                                                     AS `mch_id`,
       `a`.`create_time`                                                                                AS `create_time`,
       `a`.`staff_id`                                                                                   AS `staff_id`,
       `a`.`opt_id`                                                                                     AS `opt_id`,
       `b`.`no`                                                                                         AS `no`,
       `c`.`name`                                                                                       AS `site_name`,
       (select `d`.`name` from `sweeppayvendingcommon`.`dc_user` `d` where (`a`.`staff_id` = `d`.`id`)) AS `real_name`,
       (select `d`.`name`
        from `sweeppayvendingcommon`.`dc_user` `d`
        where (`a`.`opt_id` = `d`.`id`))                                                                AS `opt_real_name`,
       `e`.`name`                                                                                       AS `partition_name`,
       `f`.`name`                                                                                       AS `line_name`
from ((((`sweeppayvendingcommon`.`dc_replenishment_record` `a` left join `sweeppayvendingcommon`.`dc_device_info` `b` on ((`a`.`device_id` = `b`.`id`))) left join `sweeppayvendingcommon`.`dc_site` `c` on ((`b`.`site_id` = `c`.`id`))) left join `sweeppayvendingcommon`.`dc_partition` `e` on ((`c`.`partition_id` = `e`.`id`)))
         left join `sweeppayvendingcommon`.`dc_line` `f` on ((`c`.`line_id` = `f`.`id`)));

-- comment on column view_replenishment_record.id not supported: 补货记录唯一标识

-- comment on column view_replenishment_record.device_id not supported: 售货机ID

-- comment on column view_replenishment_record.num not supported: 补货数量

-- comment on column view_replenishment_record.mch_id not supported: 商户ID

-- comment on column view_replenishment_record.create_time not supported: 创建时间

-- comment on column view_replenishment_record.staff_id not supported: 补货员ID

-- comment on column view_replenishment_record.opt_id not supported: 执行人

-- comment on column view_replenishment_record.no not supported: 售货机编号

-- comment on column view_replenishment_record.site_name not supported: 点位名称

-- comment on column view_replenishment_record.partition_name not supported: 点位分区名称

-- comment on column view_replenishment_record.line_name not supported: 线路名称


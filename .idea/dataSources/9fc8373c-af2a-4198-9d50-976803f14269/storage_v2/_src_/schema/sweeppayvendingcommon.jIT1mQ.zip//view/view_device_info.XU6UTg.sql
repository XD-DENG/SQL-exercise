create definer = root@`%` view view_device_info as
select distinct `di`.`id`                                  AS `id`,
                `di`.`no`                                  AS `no`,
                `di`.`status`                              AS `status`,
                `di`.`activation_time`                     AS `activation_time`,
                `di`.`num`                                 AS `num`,
                `di`.`container_number`                    AS `container_number`,
                `di`.`capacity`                            AS `capacity`,
                `di`.`memo`                                AS `memo`,
                `di`.`mch_id`                              AS `mch_id`,
                `di`.`creator_id`                          AS `creator_id`,
                `di`.`last_modifier_id`                    AS `last_modifier_id`,
                `di`.`last_modify_time`                    AS `last_modify_time`,
                ifnull((select `r`.`staff_id`
                        from `sweeppayvendingcommon`.`dc_device_staff_rela` `r`
                        where (`di`.`id` = `r`.`id`)), '') AS `staff_id`,
                `di`.`site_id`                             AS `site_id`,
                ifnull(`s`.`name`, '')                     AS `site_name`,
                ifnull(`s`.`partition_id`, '')             AS `partition_id`,
                ifnull(`p`.`name`, '')                     AS `partition_name`,
                ifnull(`s`.`line_id`, '')                  AS `line_id`,
                ifnull(`l`.`name`, '')                     AS `line_name`,
                ifnull(`p`.`org_id`, '')                   AS `org_id`,
                ifnull(`s`.`location_address`, '')         AS `s_location_address`,
                ifnull(`s`.`address`, '')                  AS `s_address`,
                ifnull(`s`.`longitude`, '')                AS `s_longitude`,
                ifnull(`s`.`latitude`, '')                 AS `s_latitude`,
                ifnull(`s`.`provice_id`, '')               AS `provice_id`,
                ifnull(`s`.`city_id`, '')                  AS `city_id`,
                ifnull(`s`.`county_id`, '')                AS `county_id`,
                ifnull(`dm`.`id`, '')                      AS `model_id`,
                ifnull(`dm`.`name`, '')                    AS `model_name`,
                ifnull(`dm`.`images`, '')                  AS `m_images`,
                ifnull(`dc`.`id`, '')                      AS `control_id`,
                ifnull(`dc`.`name`, '')                    AS `control_name`,
                `dor`.`relation_tree`                      AS `relation_tree`,
                `dor`.`code`                               AS `code`,
                `dor`.`pid`                                AS `pid`
from ((((((`sweeppayvendingcommon`.`dc_device_info` `di` left join `sweeppayvendingcommon`.`dc_site` `s` on (((`s`.`id` = `di`.`site_id`) and (`s`.`mch_id` = `di`.`mch_id`)))) left join `sweeppayvendingcommon`.`dc_partition` `p` on (((`p`.`mch_id` = `di`.`mch_id`) and (`s`.`partition_id` = `p`.`id`)))) left join `sweeppayvendingcommon`.`dc_org` `dor` on ((`p`.`org_id` = `dor`.`id`))) left join `sweeppayvendingcommon`.`dc_line` `l` on (((`l`.`id` = `s`.`line_id`) and (`l`.`mch_id` = `di`.`mch_id`)))) left join `sweeppayvendingcommon`.`dc_device_model` `dm` on ((`di`.`device_model_id` = `dm`.`id`)))
         left join `sweeppayvendingcommon`.`dc_device_control` `dc` on ((`dm`.`control_id` = `dc`.`id`)))
where ((1 = 1) and exists(select 1
                          from `sweeppayvendingcommon`.`dc_org` `o`
                          where ((`o`.`relation_tree` like concat(`o`.`relation_tree`, '%')) and
                                 (`p`.`org_id` = `o`.`id`))));

-- comment on column view_device_info.id not supported: 售货机信息唯一标识

-- comment on column view_device_info.no not supported: 售货机编号

-- comment on column view_device_info.status not supported: 状态 0 禁用 1 启用

-- comment on column view_device_info.activation_time not supported: 激活时间

-- comment on column view_device_info.num not supported: 货道数

-- comment on column view_device_info.container_number not supported: 货柜数

-- comment on column view_device_info.capacity not supported: 总容量

-- comment on column view_device_info.memo not supported: 备注

-- comment on column view_device_info.mch_id not supported: 商户ID

-- comment on column view_device_info.creator_id not supported: 创建人ID

-- comment on column view_device_info.last_modifier_id not supported: 最后修改者ID

-- comment on column view_device_info.last_modify_time not supported: 最后修改时间

-- comment on column view_device_info.site_id not supported: 所在点位ID

-- comment on column view_device_info.relation_tree not supported: 关系树，用“-”分割机构ID，如：1-2-3-

-- comment on column view_device_info.code not supported: 编码

-- comment on column view_device_info.pid not supported: 上级ID


create
    definer = root@`%` procedure menu_tools()
BEGIN

INSERT INTO vending.dc_menu (id, code, name, url, icon, sort, pid, relation_tree, available, 
description, create_time, creator_id, last_modify_time, last_modifier_id) 

SELECT m.id,m.menu_code,m.menu_name,m.menu_url,m.menu_icon,1,m.sid,m.relation_no,1,m.remarks,NOW(),'1',NOW(),'1' FROM t_menu m; 




END;


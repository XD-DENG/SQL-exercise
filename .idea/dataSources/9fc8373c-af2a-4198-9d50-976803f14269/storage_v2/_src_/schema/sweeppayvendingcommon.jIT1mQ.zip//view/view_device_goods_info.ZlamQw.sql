create definer = root@`%` view view_device_goods_info as
select `dgi`.`id`               AS `id`,
       `dgi`.`device_id`        AS `device_id`,
       `dgi`.`container_id`     AS `container_id`,
       `dgi`.`container_no`     AS `container_no`,
       `dgi`.`row`              AS `row`,
       `dgi`.`col`              AS `col`,
       `dgi`.`capacity`         AS `capacity`,
       `dgi`.`goods_id`         AS `goods_id`,
       `dgi`.`stock_num`        AS `stock_num`,
       `dgi`.`price`            AS `price`,
       `dgi`.`mch_id`           AS `mch_id`,
       `dgi`.`create_time`      AS `create_time`,
       `dgi`.`creator_id`       AS `creator_id`,
       `dgi`.`last_modify_time` AS `last_modify_time`,
       `dgi`.`last_modifier_id` AS `last_modifier_id`,
       `g`.`code`               AS `goods_code`,
       `g`.`name`               AS `goods_name`,
       `g`.`picture`            AS `goods_picture`,
       `di`.`no`                AS `device_no`,
       `dc`.`name`              AS `device_container_name`
from (((`sweeppayvendingcommon`.`dc_device_goods_info` `dgi` left join `sweeppayvendingcommon`.`dc_goods` `g` on ((`dgi`.`goods_id` = `g`.`id`))) left join `sweeppayvendingcommon`.`dc_device_info` `di` on ((`dgi`.`device_id` = `di`.`id`)))
         left join `sweeppayvendingcommon`.`dc_device_container` `dc` on ((`dgi`.`container_id` = `dc`.`id`)));

-- comment on column view_device_goods_info.id not supported: 主键ID

-- comment on column view_device_goods_info.device_id not supported: 售货机唯一标识

-- comment on column view_device_goods_info.container_id not supported: 货柜ID

-- comment on column view_device_goods_info.container_no not supported: 货柜编号

-- comment on column view_device_goods_info.row not supported: 货道行号

-- comment on column view_device_goods_info.col not supported: 货道列号

-- comment on column view_device_goods_info.capacity not supported: 容量

-- comment on column view_device_goods_info.goods_id not supported: 商品ID

-- comment on column view_device_goods_info.stock_num not supported: 商品库存

-- comment on column view_device_goods_info.price not supported: 商品售价

-- comment on column view_device_goods_info.mch_id not supported: 商户ID

-- comment on column view_device_goods_info.create_time not supported: 创建时间

-- comment on column view_device_goods_info.creator_id not supported: 创建人ID

-- comment on column view_device_goods_info.last_modify_time not supported: 最后修改时间

-- comment on column view_device_goods_info.last_modifier_id not supported: 最后修改者ID

-- comment on column view_device_goods_info.goods_code not supported: 编号

-- comment on column view_device_goods_info.goods_name not supported: 名称

-- comment on column view_device_goods_info.goods_picture not supported: 图片

-- comment on column view_device_goods_info.device_no not supported: 售货机编号

-- comment on column view_device_goods_info.device_container_name not supported: 货柜型号


create definer = root@`%` view view_day as
select `a`.`p_time`                           AS `p_time`,
       ifnull(`a`.`p_year`, `a`.`p_year_now`) AS `p_year`,
       `a`.`p_month`                          AS `p_month`,
       `a`.`p_day`                            AS `p_day`,
       `a`.`actual_price_sum`                 AS `actual_price_sum`,
       `a`.`total_price_sum`                  AS `total_price_sum`,
       `a`.`cou`                              AS `cou`,
       `a`.`p_time_now`                       AS `p_time_now`,
       ifnull(`a`.`p_year_now`, `a`.`p_year`) AS `p_year_now`,
       `a`.`p_month_now`                      AS `p_month_now`,
       `a`.`p_day_now`                        AS `p_day_now`,
       `a`.`actual_price_sum_now`             AS `actual_price_sum_now`,
       `a`.`total_price_sum_now`              AS `total_price_sum_now`,
       `a`.`cou_now`                          AS `cou_now`
from (select `t1`.`p_time`               AS `p_time`,
             `t1`.`p_year`               AS `p_year`,
             `t1`.`p_month`              AS `p_month`,
             `t1`.`p_day`                AS `p_day`,
             `t1`.`actual_price_sum`     AS `actual_price_sum`,
             `t1`.`total_price_sum`      AS `total_price_sum`,
             `t1`.`cou`                  AS `cou`,
             `t2`.`p_time_now`           AS `p_time_now`,
             `t2`.`p_year_now`           AS `p_year_now`,
             `t2`.`p_month_now`          AS `p_month_now`,
             `t2`.`p_day_now`            AS `p_day_now`,
             `t2`.`actual_price_sum_now` AS `actual_price_sum_now`,
             `t2`.`total_price_sum_now`  AS `total_price_sum_now`,
             `t2`.`cou_now`              AS `cou_now`
      from (((select date_format(`o`.`pay_time`, '%Y-%m-%d') AS `p_time`,
                     date_format(`o`.`pay_time`, '%H')       AS `p_year`,
                     date_format(`o`.`pay_time`, '%i')       AS `p_month`,
                     date_format(`o`.`pay_time`, '%s')       AS `p_day`,
                     sum(`o`.`actual_price`)                 AS `actual_price_sum`,
                     sum(`o`.`total_price`)                  AS `total_price_sum`,
                     count(0)                                AS `cou`
              from `screenvending`.`dc_order` `o`
              where ((1 = 1) and (convert(date_format(`o`.`pay_time`, '%Y-%m-%d') using utf8mb4) = '2017-06-06') and
                     (`o`.`mch_id` = '0'))
              group by date_format(`o`.`pay_time`, '%Y-%m-%d %H'))) `t1`
               left join (select date_format(`o`.`pay_time`, '%Y-%m-%d') AS `p_time_now`,
                                 date_format(`o`.`pay_time`, '%H')       AS `p_year_now`,
                                 date_format(`o`.`pay_time`, '%i')       AS `p_month_now`,
                                 date_format(`o`.`pay_time`, '%s')       AS `p_day_now`,
                                 sum(`o`.`actual_price`)                 AS `actual_price_sum_now`,
                                 sum(`o`.`total_price`)                  AS `total_price_sum_now`,
                                 count(0)                                AS `cou_now`
                          from `screenvending`.`dc_order` `o`
                          where ((1 = 1) and
                                 (convert(date_format(`o`.`pay_time`, '%Y-%m-%d') using utf8mb4) = '2017-06-07') and
                                 (`o`.`mch_id` = '0'))
                          group by date_format(`o`.`pay_time`, '%Y-%m-%d %H')) `t2`
                         on ((`t1`.`p_year` = `t2`.`p_year_now`)))
      union
      select `t1`.`p_time`               AS `p_time`,
             `t1`.`p_year`               AS `p_year`,
             `t1`.`p_month`              AS `p_month`,
             `t1`.`p_day`                AS `p_day`,
             `t1`.`actual_price_sum`     AS `actual_price_sum`,
             `t1`.`total_price_sum`      AS `total_price_sum`,
             `t1`.`cou`                  AS `cou`,
             `t2`.`p_time_now`           AS `p_time_now`,
             `t2`.`p_year_now`           AS `p_year_now`,
             `t2`.`p_month_now`          AS `p_month_now`,
             `t2`.`p_day_now`            AS `p_day_now`,
             `t2`.`actual_price_sum_now` AS `actual_price_sum_now`,
             `t2`.`total_price_sum_now`  AS `total_price_sum_now`,
             `t2`.`cou_now`              AS `cou_now`
      from (((select date_format(`o`.`pay_time`, '%Y-%m-%d') AS `p_time_now`,
                     date_format(`o`.`pay_time`, '%H')       AS `p_year_now`,
                     date_format(`o`.`pay_time`, '%i')       AS `p_month_now`,
                     date_format(`o`.`pay_time`, '%s')       AS `p_day_now`,
                     sum(`o`.`actual_price`)                 AS `actual_price_sum_now`,
                     sum(`o`.`total_price`)                  AS `total_price_sum_now`,
                     count(0)                                AS `cou_now`
              from `screenvending`.`dc_order` `o`
              where ((1 = 1) and (convert(date_format(`o`.`pay_time`, '%Y-%m-%d') using utf8mb4) = '2017-06-07') and
                     (`o`.`mch_id` = '0'))
              group by date_format(`o`.`pay_time`, '%Y-%m-%d %H'))) `t2`
               left join (select date_format(`o`.`pay_time`, '%Y-%m-%d') AS `p_time`,
                                 date_format(`o`.`pay_time`, '%H')       AS `p_year`,
                                 date_format(`o`.`pay_time`, '%i')       AS `p_month`,
                                 date_format(`o`.`pay_time`, '%s')       AS `p_day`,
                                 sum(`o`.`actual_price`)                 AS `actual_price_sum`,
                                 sum(`o`.`total_price`)                  AS `total_price_sum`,
                                 count(0)                                AS `cou`
                          from `screenvending`.`dc_order` `o`
                          where ((1 = 1) and
                                 (convert(date_format(`o`.`pay_time`, '%Y-%m-%d') using utf8mb4) = '2017-06-06') and
                                 (`o`.`mch_id` = '0'))
                          group by date_format(`o`.`pay_time`, '%Y-%m-%d %H')) `t1`
                         on ((`t1`.`p_year` = `t2`.`p_year_now`)))) `a`
order by ifnull(`a`.`p_year`, `a`.`p_year_now`);

